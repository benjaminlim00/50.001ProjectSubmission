package com.example.benjamin.sutdregistration;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FailurePage extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.failure_page);

        String name = getIntent().getStringExtra("Username");

        TextView textView = findViewById(R.id.failuretext);
        textView.setText("Failed Verification! \n" +
        "Please approach the nearest staff for manual verification, " +
                name + ".");

        Button button = findViewById(R.id.failurebutton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(FailurePage.this, MainActivity.class);
                startActivity(i);
            }
        });


    }
}
