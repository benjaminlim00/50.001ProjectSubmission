package com.example.benjamin.sutdregistration;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import com.google.gson.JsonObject;
import com.publit.publit_io.utils.PublitioCallback;
import com.publit.publit_io.utils.Publitio;
import java.util.HashMap;
import java.util.Map;


public class CameraActivity extends AppCompatActivity {

    private Button buttonImage;
    private Button newRegistration;
    private ImageView imageView;
    ContentValues values;
    Uri imageUri;
    String imageurl;
    private String studentID;
    Publitio mPublitio;


    private static final int REQUEST_ID_READ_WRITE_PERMISSION = 99;
    private static final int REQUEST_ID_IMAGE_CAPTURE = 100;

    //creating reference to firebase storage
    //THIS IS NEEDED!!!
    FirebaseStorage storage;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera_page);


        //To fix permission issues before the activity runs
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int readPermission = ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE);
            int writePermission = ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int internetPermission = ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_NETWORK_STATE);
            int networkPermission = ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_NETWORK_STATE);


            if (writePermission != PackageManager.PERMISSION_GRANTED ||
                    readPermission != PackageManager.PERMISSION_GRANTED ||
                    internetPermission != PackageManager.PERMISSION_GRANTED ||
                    networkPermission != PackageManager.PERMISSION_GRANTED) {
                // If don't have permission so prompt the user.
                this.requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.ACCESS_NETWORK_STATE,
                                Manifest.permission.INTERNET},
                        REQUEST_ID_READ_WRITE_PERMISSION
                );
            }
        }


        //retrieve the data from previous activity - studentID
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            studentID = extras.getString("STUDENT_ID");
        }

        //new registration button: brings back to main_activity
        newRegistration = this.findViewById(R.id.button_image2);
        newRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CameraActivity.this, MainActivity.class);
                startActivity(i);
            }
        });


        this.buttonImage = this.findViewById(R.id.button_image);
        this.imageView = this.findViewById(R.id.imageView);

        this.buttonImage.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        // Check for Approved List on Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRefApproved = database.getReference("Approved");

        myRefApproved.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                String name = dataSnapshot.child("name").getValue(String.class);
                String id = dataSnapshot.getKey();

                if (!id.equals("default")) {
                    if (studentID.equals(id)) {
                        //here we bring the user to a successfully logged in page.
                        Intent i = new Intent(CameraActivity.this, SuccessPage.class);
                        i.putExtra("Username", name);   //we send the username over
                        startActivity(i);
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });
//         Check for Awaiting Manual Approval List on Firebase, so that when there is a failure, we go to failure page.
        DatabaseReference awaitingManualApproval = FirebaseDatabase.getInstance().getReference("Awaiting Manual Approval");
        awaitingManualApproval.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                String id = dataSnapshot.getKey();
                if (!id.equals("default")) {
                    String name = dataSnapshot.child("name").getValue(String.class);
                    if (studentID.equals(id)) {
                        Intent i = new Intent(CameraActivity.this, FailurePage.class);
                        i.putExtra("Username", name);
                        startActivity(i);
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });

    }

    //start an intent to take a picture
    private void captureImage() {
        values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From your Camera");
        imageUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        // Create an implicit intent, for image capture.
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        // Start camera and wait for the results.
        startActivityForResult(intent, REQUEST_ID_IMAGE_CAPTURE);
    }

    // When you have the request results for permissions
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_ID_READ_WRITE_PERMISSION: {
                // Note: If request is cancelled, the result arrays are empty.
                // Permissions granted (read/write).
                if (grantResults.length > 1
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED
                        && grantResults[2] == PackageManager.PERMISSION_GRANTED
                        && grantResults[3] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, "Permission granted!", Toast.LENGTH_LONG).show();
                }
                // Cancelled or denied.
                else {
                    Toast.makeText(this, "Permission denied!", Toast.LENGTH_LONG).show();
                }
                break;
            }
        }
    }

    // When results returned from the intent to take a picture
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //we make use of publito API to retrieve an image url
        mPublitio = new Publitio(this);
        Map<String, String> create = new HashMap<>();

        if (requestCode == REQUEST_ID_IMAGE_CAPTURE) {
            if (resultCode == RESULT_OK) {
                try {
                    //we retrieve the bitmap form the intent
                    Bitmap pic = MediaStore.Images.Media.getBitmap(
                            getContentResolver(), imageUri);
                    this.imageView.setImageBitmap(pic);
                    imageurl = getRealPathFromURI(imageUri);
                    //we retrieve an publito callback
                    mPublitio.files().uploadFile(imageUri, create, new PublitioCallback<JsonObject>() {
                        @Override
                        public void success(JsonObject result) {
                            //get instance of firebase database and insert publito URL to it
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference("Awaiting Approval");
                            myRef.child(studentID).child("url_download").setValue(result.get("url_download").toString());
                        }

                        @Override
                        public void failure(String message) {
                            Toast.makeText(CameraActivity.this, "Error uploading to publito", Toast.LENGTH_LONG).show();
                        }
                    });

                    Toast.makeText(CameraActivity.this,
                            "Upload successful\nPlease wait while we verify your identity",
                            Toast.LENGTH_LONG).show();

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "ERROR", Toast.LENGTH_SHORT).show();
                }

            }   else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Action canceled", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Action Failed", Toast.LENGTH_LONG).show();
            }
        }
    }

    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor
                .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
}