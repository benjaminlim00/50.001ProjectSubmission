package com.example.benjamin.regnewuser;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.publit.publit_io.utils.Publitio;


public class MainActivity extends AppCompatActivity {
    Button button;
    EditText id;
    EditText name;
    EditText idtype;
    ContentValues values;

    //creating reference to firebase storage
    //THIS IS NEEDED!!!
    FirebaseStorage storage;
    StorageReference storageReference;


    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference usersNode = database.getReference("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.registerbutton);
        id = findViewById(R.id.idfield);
        name = findViewById(R.id.namefield);
        idtype = findViewById(R.id.typefield);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String idstring = id.getText().toString();
                String namestring = name.getText().toString();
                String idtypestring = idtype.getText().toString();

                Toast.makeText(MainActivity.this, "sending data to database...", Toast.LENGTH_LONG).show();
                //we upload the data to firebase onclick
                try {
                    usersNode.child(idstring).child("approved").setValue(0);
                    usersNode.child(idstring).child("name").setValue(namestring);
                    usersNode.child(idstring).child("test_image_url").setValue("");
                    usersNode.child(idstring).child("type").setValue(idtypestring);
                }catch (NullPointerException e) {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_LONG).show();
                }

                Intent i = new Intent(MainActivity.this, CameraActivity.class);
                i.putExtra("STUDENT_ID", idstring); //send studentID over
                startActivity(i);
            }
        });
    }
}
